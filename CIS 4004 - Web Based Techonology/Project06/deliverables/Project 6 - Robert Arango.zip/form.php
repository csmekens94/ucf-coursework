<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Atlantic Trails Resort</title>
    <link href="form.css" media="all" rel="stylesheet" type="text/css" />
</head>

<body>

    <div id="page-wrapper">
        
        <div id="header-wrapper">
        
            <header role="banner">
                Atlantic Trails Resort
            </header>
        
        </div>
        
        <div id="content-wrapper">
            
            <div id="main-content">
                
                <section role="main">
                    
                    <h2 role="heading">We will be contacting you soon!</h2>
                    
                    <h3>Here is the information you entered:</h3>
                    
                    <br/>
                    <br/>
                    <br/>
                    <br/>
                    <br/>
                    <br/>
                    
                    <form action="#" role="form">
                        <input type="button" value = "Back" onclick="javascript:history.go(-1)" />
                    </form>
                
                </section>
            
            </div>
            
        </div>
        
    </div>
        
</body>

</html>